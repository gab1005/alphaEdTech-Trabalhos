type Item = {
  id?: number;
  nome: string;
  descricao: string;
};
export default Item;
